const TextEntry = require('../models/TextEntry');

exports.submitText = async (req, res) => {
  try {
    const { text } = req.body;
    const textEntry = new TextEntry({ text });
    await textEntry.save();
    res.status(200).send('Text submitted');
  } catch (error) {
    res.status(500).send(error.message);
  }
};
