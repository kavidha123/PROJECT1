const ConnectionLog = require('../models/ConnectionLog');

exports.logConnection = async (req, res) => {
  try {
    const logEntry = new ConnectionLog({ ipAddress: req.ip });
    await logEntry.save();
    res.status(200).send('Connection logged');
  } catch (error) {
    res.status(500).send(error.message);
  }
};
