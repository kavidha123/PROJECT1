const axios = require('axios');
const DJANGO_API_URL = 'http://localhost:8000/ngrams'; // Replace with your Django API URL

exports.getNgramsComparison = async (req, res) => {
  try {
    const text1 = req.body.text1; // Assuming you are sending two text inputs
    const text2 = req.body.text2;
    const response = await axios.post(DJANGO_API_URL, { text1, text2 });
    res.json(response.data);
  } catch (error) {
    res.status(500).send({ message: "Error connecting to Django API", error: error.message });
  }
};
