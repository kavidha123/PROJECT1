const mongoose = require('mongoose');

const ConnectionLogSchema = new mongoose.Schema({
  timestamp: { type: Date, default: Date.now },
  ipAddress: String,
});

module.exports = mongoose.model('ConnectionLog', ConnectionLogSchema);
