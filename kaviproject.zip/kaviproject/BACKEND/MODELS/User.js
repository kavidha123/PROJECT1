const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  userId: String,
  friendList: [String], // Array of user IDs
  // Other user fields...
});

module.exports = mongoose.model('User', UserSchema);
