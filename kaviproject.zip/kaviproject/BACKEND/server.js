const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const connectionRoutes = require('./routes/connectionRoutes');
const textRoutes = require('./routes/textRoutes');
const userRoutes = require('./routes/userRoutes');
const ngramRoutes = require('./routes/ngramRoutes');

const app = express();

// Database connection
mongoose.connect('mongodb://localhost:27017/yourDatabase', { useNewUrlParser: true, useUnifiedTopology: true });

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// Multer and other middlewares...

// Routes
app.use('/api/connections', connectionRoutes);
app.use('/api/texts', textRoutes);
app.use('/api/users', userRoutes);
app.use('/api/ngrams', ngramRoutes);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
