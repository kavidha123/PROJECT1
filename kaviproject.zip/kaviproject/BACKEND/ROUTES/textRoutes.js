const express = require('express');
const router = express.Router();
const textController = require('../controllers/textController');

router.post('/submit', textController.submitText);

module.exports = router;
