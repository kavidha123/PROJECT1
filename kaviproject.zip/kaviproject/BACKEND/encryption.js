const crypto = require('crypto');
const algorithm = 'aes-256-cbc'; // Encryption algorithm
const secretKey = 'yourSecretKey'; // Replace with a secret key
const iv = crypto.randomBytes(16); // Initialization vector

const encrypt = (text) => {
  let cipher = crypto.createCipheriv(algorithm, Buffer.from(secretKey), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
}

const decrypt = (encryption) => {
  let iv = Buffer.from(encryption.iv, 'hex');
  let encryptedText = Buffer.from(encryption.encryptedData, 'hex');
  let decipher = crypto.createDecipheriv(algorithm, Buffer.from(secretKey), iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

module.exports = { encrypt, decrypt };
