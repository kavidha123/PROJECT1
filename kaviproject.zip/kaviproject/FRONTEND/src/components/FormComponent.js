import React, { useState } from 'react';
import apiService from './services/apiService';

function FormComponent() {
    const [id, setId] = useState('');
    const [friendId, setFriendId] = useState('');
    const [password, setPassword] = useState('');
    const [file, setFile] = useState(null);

    const handleSubmit = async (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append('id', id);
        formData.append('friendId', friendId);
        formData.append('password', password);
        formData.append('file', file);

        try {
            const response = await apiService.sendData(formData);
            console.log(response.data);
        } catch (error) {
            console.error('Error submitting form:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" value={id} onChange={e => setId(e.target.value)} placeholder="ID" />
            <input type="text" value={friendId} onChange={e => setFriendId(e.target.value)} placeholder="Friend ID" />
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" />
            <input type="file" onChange={e => setFile(e.target.files[0])} />
            <button type="submit">Submit</button>
        </form>
    );
}

export default FormComponent;
