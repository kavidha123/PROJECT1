import axios from 'axios';

const BASE_URL = 'http://localhost:5000'; // Adjust as per your backend URL

const sendData = async (formData) => {
    try {
        const response = await axios.post(`${BASE_URL}/submit-data`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response;
    } catch (error) {
        throw error;
    }
};

const apiService = {
    sendData,
};

export default apiService;