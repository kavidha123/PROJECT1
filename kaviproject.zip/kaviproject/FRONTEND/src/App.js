import React from 'react';
import FormComponent from './FormComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>My PWA</h1>
      </header>
      <main>
        <FormComponent />
      </main>
    </div>
  );
}

export default App;
