from django.urls import path
from .views import ngram_analysis

urlpatterns = [
    path('analyze/', ngram_analysis, name='ngram_analysis'),
]
