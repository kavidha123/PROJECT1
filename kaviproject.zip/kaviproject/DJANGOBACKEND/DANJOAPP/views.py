from django.http import JsonResponse
from nltk.util import ngrams
from nltk.tokenize import word_tokenize
import nltk

nltk.download('punkt')

def generate_ngrams(text, n):
    words = word_tokenize(text)
    return [' '.join(grams) for grams in ngrams(words, n)]

def ngram_analysis(request):
    if request.method == 'POST':
        data = request.POST
        text1 = data.get('text1')
        text2 = data.get('text2')
        n = int(data.get('n', 2))  # default to bigrams

        ngrams1 = generate_ngrams(text1, n)
        ngrams2 = generate_ngrams(text2, n)

        return JsonResponse({
            'text1_ngrams': ngrams1,
            'text2_ngrams': ngrams2
        })
    else:
        return JsonResponse({'error': 'Invalid request'}, status=400)
