from django.db import models

class TextAnalysis(models.Model):
    """
    Model to store texts that are analyzed.
    """
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"TextAnalysis(id={self.id})"

class NgramResult(models.Model):
    """
    Model to store the results of the N-gram analysis.
    """
    text_analysis = models.ForeignKey(TextAnalysis, on_delete=models.CASCADE)
    ngram_size = models.PositiveIntegerField()
    ngrams = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"NgramResult(id={self.id}, ngram_size={self.ngram_size})"
