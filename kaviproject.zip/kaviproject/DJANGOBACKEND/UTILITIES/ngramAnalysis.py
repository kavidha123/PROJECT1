# ngramAnalysis.py

from nltk.util import ngrams
from nltk.tokenize import word_tokenize
import nltk

# Ensure the necessary NLTK data (tokenizers, etc.) are downloaded
nltk.download('punkt')

def generate_ngrams(text, n):
    """
    Generates n-grams from the given text.

    :param text: The input text string.
    :param n: The size of the n-gram (e.g., 2 for bigrams).
    :return: A list of n-grams.
    """
    # Tokenize the text into words
    words = word_tokenize(text)

    # Generate and return the n-grams
    return [' '.join(grams) for grams in ngrams(words, n)]
